package puzzles.jaxb;

public class ReaderJaxb {
    public static void main(String[] args) {

    }
}
