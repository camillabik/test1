package puzzles;

import java.io.File;
import java.nio.file.Path;
import java.util.Set;

public class Question {
   private Category category;
   private int id;
   private String name;
   private String pathToTextQuestion;
   private Path pathToPictureQuestion;

   public Question(Category category, int id, String name, String TextQuestion) {
      this.category = category;
      this.id = id;
      this.name = name;
      this.pathToTextQuestion = pathToTextQuestion;
   }

   public Question(Category category, int id, String name, Path pathToPictureQuestion) {
      this.category = category;
      this.id = id;
      this.name = name;
      this.pathToPictureQuestion = pathToPictureQuestion;
   }

   public Category getCategory() {
      return category;
   }

   public void setCategory(Category category) {
      this.category = category;
   }

   public int getId() {
      return id;
   }

   public void setId(int id) {
      this.id = id;
   }

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public String getPathToTextQuestion() {
      return pathToTextQuestion;
   }

   public void setPathToTextQuestion(String pathToTextQuestion) {
      this.pathToTextQuestion = pathToTextQuestion;
   }

   public Path getPathToPictureQuestion() {
      return pathToPictureQuestion;
   }

   public void setPathToPictureQuestion(Path pathToPictureQuestion) {
      this.pathToPictureQuestion = pathToPictureQuestion;
   }
}
