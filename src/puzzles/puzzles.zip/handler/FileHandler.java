package puzzles.handler;

public class FileHandler {
}
