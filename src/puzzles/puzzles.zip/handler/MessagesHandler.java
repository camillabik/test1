package puzzles.handler;

public class MessagesHandler {
}
