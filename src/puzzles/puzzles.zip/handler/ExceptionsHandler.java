package puzzles.handler;

public class ExceptionsHandler {
}
