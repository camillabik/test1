package puzzles;

public enum Category {
}
