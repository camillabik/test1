package classCode.stock;

public class BreadWare {
    private static int count;

    public BreadWare(int count) {
        this.count = count;
    }

    public int getCount() {
        return count;
    }
}
