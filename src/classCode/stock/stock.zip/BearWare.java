package classCode.stock;

public class BearWare {
    private static int count;

    public BearWare(int count) {
        this.count = count;
    }

    public int getCount() {
        return count;
    }
}
