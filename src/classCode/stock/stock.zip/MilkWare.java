package classCode.stock;

public class MilkWare {
    private static int count;

    public MilkWare(int count) {
        this.count = count;
    }

    public int getCount() {
        return count;
    }
}
