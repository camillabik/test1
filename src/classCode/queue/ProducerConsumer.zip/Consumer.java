package classCode.queue;

import java.util.concurrent.TimeUnit;

public class Consumer implements Runnable {
    private Producer producer;
    private int count = 0;

    public Consumer(Producer producer) {
        this.producer = producer;
    }

    @Override
    public void run() {
        while (true) {

            String s = null;
            try {
                s = producer.getLinkedBlockingQueue().poll(500, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            s = s.replaceAll("[\\p{P}]", "");
            String[] arr = s.split("[\\s+]");
            for (String s1 : arr) {
                if (s1.matches("страдание"));
                count++;
            }
            System.out.println("Cловo \"страдание\" встречается " + count+ "раз(а)");



        }

    }
}
